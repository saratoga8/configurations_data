#!/usr/bin/ruby

# Class for finding SSL errors in the given browser logs
class SslFindErrs
  ##
  # Initialization
  # * +logs+ - Logs from browser
  # * +ignorations_path+ - The path to the file with ignorances for searching errors
  # * +errs_path+ - The path to the file with errors should be found the given logs
  ##
  def initialize(logs, ignorations_path, errs_path)
    @logs         = logs
    @ignorations  = IO.readlines(ignorations_path).reject { |line| line.start_with?("//") }    # read lines from the ignorations file (not starting with //) to array
    @errs         = IO.readlines(errs_path).reject        { |line| line.start_with?("//") }    # read lines from the errors file      (not starting with //) to array
  end

  ##
  # Get logs with found errors
  ##
  def getErrs
    puts "Initial log: #{@logs}"
    @logs = @logs.reject { |log| @errs.each { |err| !log.to_s.include? err } }                 # remove all logs not containing the errors from file
    puts "Errors log: #{@logs}"
    @logs = @logs.reject { |log| containIgnoration? log.to_s }                                 # remove all logs containing ignora
  end

  ##
  # Does the given string contain ignorations
  # * +str+ - the given string
  ##
  private def containIgnoration?(str)
    @ignorations.each do |ignoration|
      if ignoration.include? "*"
        ignoration = ignoration.gsub("*", ".*").gsub("/", "\\/").strip
        return str.match(/#{ignoration}/)
      end
      return str.include? ignoration
    end
  end
  
end
