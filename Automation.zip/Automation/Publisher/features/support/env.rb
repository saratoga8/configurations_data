require 'watir'
require 'minitest/autorun'
require 'watir-scroll'
require 'eyes_selenium'

require_relative "../support/ssl/SslFindErrs"

IGNORATIONS_PATH = File.expand_path("../../support/ssl/ignorations.url", __FILE__)
ERRS_PATH        = File.expand_path("../../support/ssl/errs.txt", __FILE__)

@url = ""
@test_name = ""

Before do |scenario|
  case ENV['BROWSER']
  when "chrome"
    @browser = Watir::Browser.new :chrome, desired_capabilities: Selenium::WebDriver::Remote::Capabilities.chrome("chromeOptions" => {"args" => [ "disable-infobars", "--start-maximized" ]})
    viewport_size = {width: 1920, height: 979}
  when "mobile"
    capabilities = { platformName: 'iOS', platformVersion: '10.3', deviceName: 'iPhone 6', browserName: 'Safari' }
    server_url = "http://192.168.2.55:4723/wd/hub/"
    driver = Selenium::WebDriver.for(:remote, :desired_capabilities => capabilities, :url => server_url)
    @browser = Watir::Browser.new driver
  else
    assert(false, "Unknown browser name " + ENV['BROWSER'])
  end

  init_applitools feature: scenario.feature.name, scenario: scenario.name, viewport_size: viewport_size
end

private def init_applitools(feature:, scenario:, viewport_size:)
  @eyes = Applitools::Selenium::Eyes.new
  @eyes.api_key = "HIC100I5CJ08tyPOkKIuU3lC1a7Xcp2UB98EN5gN10KtJU110"
  @test_name = feature + ": " + scenario
  if viewport_size == nil then
      @eyes.open(app_name: 'Landing Pages', test_name: @test_name, driver: @browser.driver)
  else
      @eyes.open(app_name: 'Landing Pages', test_name: @test_name, viewport_size: viewport_size, driver: @browser.driver)
  end
end

After do
  @browser.quit if @browser != nil
  @eyes.close @eyes != nil
end

