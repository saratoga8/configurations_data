require 'net/http'
require 'uri'

# Setting URL at the beginning (saving the given URL in the global value)
# @param url The given URL
Given (/^URL is (.+)$/) do |url|
  @url = url
end

# Open the site with the URL defined before
When (/^open site$/) do
  @browser.goto(@url)
end

# Check the page title
# @param title The expected title
Then (/^page title is "(.+)"$/) do |title|
  _actual_title = @browser.title
  begin
    Watir::Wait.until(timeout: 45) { _actual_title == title }
  rescue Watir::Wait::TimeoutError
    assert(_actual_title == title, "Expected title is #{title}, the actual one is #{_actual_title}")
  end
end

# Check tab with the given URL is OPENED/CLOSED
# @param url The URL of the tab
# @param state The expected state of the tab (OPENED/CLOSED)
Then (/^tab "(.+)" (OPENED|CLOSED)$/) do |url, state|
  Watir::Wait.until(timeout: 5) { (state == "OPENED") ? @browser.windows.length > 1: browser.windows.length == 1 }
  @browser.windows.last.use
  assert(@browser.url == url, "Expected url is #{url}, the actual one #{@browser.url}")    
end

# Check the browser's window by Applitools
# @param win_name The window name which will be shown in the Applitools results
Then (/^check window by Applitools "(.+)"$/) do |win_name|
  @eyes.check_window(win_name)
end

# Check the page has redirected to the given URL
# @param url The expected URL
Then (/^page redirected to (.+)$/) do |url|
  assert(@browser.url == url, "Expected url is #{url}, the actual one #{@browser.url}")
end

# Run the given javascript text in the browser's page
# @param javascript The text of the javascript
# @param comment The comment 
When (/^Run javascript "(.+)" \((.+)\)$/) do |javascript, comment|
  @browser.execute_script(javascript);
end

# Check the page scrolled vertically to the given position during the given time
# @param pos The given position within the page
# @param timeout The time out in seconds for the scrolling
Then (/^page scrolled vertically to position (\d+) during (\d+)s$/) do |pos, timeout|
  begin
    Watir::Wait.until(timeout.to_i, "Vertical scroll to the position #{pos} during #{timeout} seconds has failed")    { @browser.execute_script("return document.body.scrollTop") == pos.to_i }
  rescue Watir::Wait::TimeoutError
    actual_pos = @browser.execute_script("return document.body.scrollTop")
    puts "Actual position: #{actual_pos}"
  end
end

# Check SSL errors in the browser log
And (/^check SSL errors$/) do
  if ENV['BROWSER'] != "mobile" then
    found_ssl_errs = SslFindErrs.new(@browser.driver.manage.logs.get(:browser), IGNORATIONS_PATH, ERRS_PATH)
    assert(found_ssl_errs.getErrs.empty?, "Found SSL errors in the browser log")
  end
end

# Compare the HTML code of the opened page with the file text
# @param path The file path for comparing
Then (/^compare the page's HTML with the file "(.+)"$/) do |path|
  project_root_dir = __dir__.split "features"
  full_path = project_root_dir[0] + path
  assert(File.exist?(full_path), "The file #{full_path} doesn't exist")
  file_txt = File.read(full_path)

  uri = URI.parse(@url)
  response = Net::HTTP.get_response(uri)

  assert(file_txt == response.body, "The page's HTML and the file #{full_path} are different\n--------\nThe expected text: #{file_txt}\n--------\nThe actual text: #{response.body}")
end

When (/^browser go back$/) do
  @browser.back
end

When (/^browser close tab$/) do
  @browser.windows.last.close
end