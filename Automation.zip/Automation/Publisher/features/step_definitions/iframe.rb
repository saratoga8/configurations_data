# Type random user's email with given domain in a text field of an IFrame
# @param domain The e-mail domain
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
# @param name The text field's name
# @param iframe_locator_type The type of the IFrame locator (ID, CSS or CLASS)
# @param iframe_locator The IFrame's locator
Then (/^type random user's e-mail of domain "(.+)" in text field with (ID|CSS|CLASS) "(.+)" and name "(.+)" in IFrame with (ID|CSS|CLASS) "(.+)"$/) do |domain, locator_type, locator, name, iframe_locator_type, iframe_locator|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class;
  iframe_by = (iframe_locator_type == "ID") ? :id: (iframe_locator_type == "CSS") ? :css: :class;
  @browser.iframe(iframe_by => iframe_locator).text_field(by => locator).set(Time.now.to_i.to_s + "@" + domain)  
end

# Select options with given number in an element of an IFrame
# @param select_num Selection's number
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
# @param iframe_locator_type The type of the IFrame locator (ID, CSS or CLASS)
# @param iframe_locator The IFrame's locator
Then (/^select option (\d+) in element with (ID|CSS|CLASS) "(.+)" in IFrame with (ID|CSS|CLASS) "(.+)"$/) do |select_num, locator_type, locator, iframe_locator_type, iframe_locator|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class;
  iframe_by = (iframe_locator_type == "ID") ? :id: (iframe_locator_type == "CSS") ? :css: :class;
  @browser.iframe(iframe_by => iframe_locator).select_list(by => locator).when_present.select_value(select_num);
end

# Select options with given text in an element of an IFrame
# @param select_num Selection's number
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
# @param iframe_locator_type The type of the IFrame locator (ID, CSS or CLASS)
# @param iframe_locator The IFrame's locator
Then (/^select option by text "(.+)" in element with (ID|CSS|CLASS) "(.+)" in IFrame with (ID|CSS|CLASS) "(.+)"$/) do |txt, locator_type, locator, iframe_locator_type, iframe_locator|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class;
  iframe_by = (iframe_locator_type == "ID") ? :id: (iframe_locator_type == "CSS") ? :css: :class;
  @browser.iframe(iframe_by => iframe_locator).select_list(by => locator).select txt;
end


# Type given text in a text field of an IFrame
# @param txt The typed text
# @param name The text field's name
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
# @param iframe_locator_type The type of the IFrame locator (ID, CSS or CLASS)
# @param iframe_locator The IFrame's locator
When (/^type "(.+)" in text field "(.+)" with (ID|CSS|CLASS) "(.+)" in IFrame with (ID|CSS|CLASS) "(.+)"$/) do |txt, name, locator_type, locator, iframe_locator_type, iframe_locator|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class
  iframe_by = (iframe_locator_type == "ID") ? :id: (iframe_locator_type == "CSS") ? :css: :class;
  @browser.iframe(iframe_by => iframe_locator).text_field(by => locator).when_present.set txt;
end

# Click on element with given type and name which is in the given IFrame
# @param type The type of the element
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
# @param iframe_locator_type The type of the IFrame locator (ID, CSS or CLASS)
# @param iframe_locator The IFrame's locator
When (/^click on "(.+)" with (ID|CSS|CLASS) "(.+)" in IFrame with (ID|CSS|CLASS) "(.+)"$/) do |type, locator_type, locator, iframe_locator_type, iframe_locator|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class
  iframe_by = (iframe_locator_type == "ID") ? :id: (iframe_locator_type == "CSS") ? :css: :class
  @browser.iframe(iframe_by => iframe_locator).element(by => locator).click
end


