# Sleep for the given time in seconds
# @param secs the time in seconds
And (/^sleep (\d+)s$/) do |secs|
  sleep secs.to_i
end
