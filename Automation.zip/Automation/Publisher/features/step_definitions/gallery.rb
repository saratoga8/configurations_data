# Check the gallery element with the given number moved horizontally to the given position
# @param name The element's name
# @param index The element's index
# @param locator_type The type of the locator (ID, CSS)
# @param locator The element's locator
# @param to The expected postion
# @param timeout Timeout in seconds
Then (/^"(.+)" element with index number (\d+) with (ID|CSS) "(.+)" moved horizontally to (\d+) during (\d+)s$/) do |name, index, locator_type, locator, to, timeout|
  by = (locator_type == "ID") ? :id: :css
  actual_from = (@browser.elements(by => locator)[index.to_i].parent.style 'left').chomp("px").to_i
  Watir::Wait.until(timeout: timeout.to_i) { (@browser.elements(by => locator)[index.to_i].parent.style 'left').chomp("px") < to }
  Watir::Wait.until(timeout: timeout.to_i) { (@browser.elements(by => locator)[index.to_i].parent.style 'left').chomp("px") == to }
end
