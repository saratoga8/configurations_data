# Click on element with given ID 
# @param name The element's name
# @param id Element's ID
#When (/^click on "(.+)" element with ID "(.+)"$/) do |name, id|
#  @browser.element(:id => id).click
#end

# Click on element with given location, type and name
# @param type The type of the element
# @param location The element's location in the page (e.g. Header or Footer)
# @param name The element's name
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
When (/^click on "(.+)" \(in (.+)\) "(.+)" with (ID|CSS|CLASS) "(.+)"$/) do |type, location, name, locator_type, locator|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class;
  @browser.element(by => locator).click
end

# Click on element with given type and name
# @param type The type of the element
# @param name The element's name
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
When (/^click on "(.+)" "(.+)" with (ID|CSS|CLASS) "(.+)"$/) do |type, name, locator_type, locator|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class;
  @browser.element(by => locator).wait_until_present.click
end

# Click on element with given type
# @param type The type of the element
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
When (/^click on "(.+)" with (ID|CSS|CLASS) "(.+)"$/) do |type, locator_type, locator|
    by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class;
    @browser.element(by => locator).click
end


# Check element is visible or hidden
# @param name The element's name
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
# @param state The elements expected state VISIBLE or HIDDEN
Then (/^"(.+)" element with (ID|CSS|CLASS) "(.+)" is (VISIBLE|HIDDEN)$/) do |name, locator_type, locator, state|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class
  state == "VISIBLE" ? assert(@browser.element(by => locator).visible?, "The element is hidden"): assert(!@browser.element(by => locator).visible?, "The element is visible")
end

# Check element is visible or hidden during the given time
# @param name The element's name
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
# @param state The elements expected state VISIBLE or HIDDEN
# @param timeout The time out in seconds
When (/^"(.+)" element with (CSS|ID|CLASS) "(.+)" is (VISIBLE|HIDDEN) during (\d+)s$/) do |name, locator_type, locator, state, timeout|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class
  Watir::Wait.until(timeout: timeout.to_i) { state == "VISIBLE" ? @browser.element(by => locator).visible?: !@browser.element(by => locator).visible? }
end

# Check element has the given text
# @param name The element's name
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
# @param txt Expected element's text
Then (/^"(.+)" element with (ID|CSS|CLASS) "(.+)" has text "(.*)"$/) do |name, locator_type, locator, txt|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class
  _actual_txt = @browser.element(by => locator).text
  assert(_actual_txt == txt, "Expected text is '#{txt}', the actual one is '#{_actual_txt}'")
end

# Type given text in text field element
# @param txt The text for typing
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The field's locator
# @param name The element's name
When (/^type "(.+)" in text field "(.+)" with (ID|CSS|CLASS) "(.+)"$/) do |txt, name, locator_type, locator|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class
  @browser.text_field(by => locator).set(txt)
end

# Scroll to element
# @param name The element's name
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
When (/^scroll to "(.+)" element with (ID|CSS|CLASS) "(.+)"$/) do |name, locator_type, locator|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class;
  Watir::Wait.until(timeout: 5, message: "The element doesn't exist") { @browser.element(by => locator).exists? }
  @browser.element(by => locator).scroll.to :center                                                              
end

# Scroll to mobile element 
# @param name The element's name
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
When (/^scroll to mobile "(.+)" element with (ID|CSS|CLASS) "(.+)"$/) do |name, locator_type, locator|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class;
  @browser.element(by => locator).scroll.to                                                               
end



# Click on element with the given index between the same elements
# @param name The element's name
# @param index The element's index
# @param locator_type The type of the locator (ID, CSS)
# @param locator The element's locator
When (/^click on "(.+)" element with index number (\d+) with (ID|CSS) "(.+)"$/) do |name, index, locator_type, locator|
  locator_type == "ID" ? @browser.elements(:id => locator)[index.to_i].click: @browser.elements(:css => locator)[index.to_i].click
end

# Check the element with the given index is visible or hidden
# @param name The element's name
# @param index The element's index
# @param locator_type The type of the locator (ID, CSS)
# @param locator The element's locator
# @param state The elements expected state VISIBLE or HIDDEN
Then (/^"(.+)" element with index number (\d+) with (ID|CSS) "(.+)" is (VISIBLE|HIDDEN)$/) do |name, index, locator_type, locator, state|
  by = (locator_type == "ID") ? :id: :css;
  state == "VISIBLE" ? assert(@browser.elements(by => locator)[index.to_i].visible?, "The element is hidden"): assert(!@browser.elements(by => locator)[index.to_i].visible?, "The element is visible")
end

# Check existence of element
# @param name The element's name
# @param locator_type The element's locator type
# @param locator The element's locator
# @param state The expected state of the element: exists or doesn't
# @param timeout Time out of awaiting in seconds
When (/^"(.+)" element with (CSS|ID|CLASS) "(.+)" (EXISTS|DOESNT_EXIST) during (\d+)s$/) do |name, locator_type, locator, state, timeout|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class
  Watir::Wait.until(timeout: timeout.to_i) { state == "VISIBLE" ? @browser.element(by => locator).exists?: !@browser.element(by => locator).exists? }
end

# Check visibility of element with index during the given time
# @param name The element's name
# @param index The element's index
# @param locator_type The element's locator type
# @param locator The element's locator
# @param state The expected state of the element: visible or hidden
# @param timeout Time out of awaiting in seconds
Then (/^"(.+)" element with index number (\d+) with (ID|CSS|CLASS) "(.+)" is (VISIBLE|HIDDEN) during (\d+)s$/) do |name, index, locator_type, locator, state, timeout|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class
  found_element = @browser.elements(by => locator)[index.to_i];
  Watir::Wait.until(timeout: timeout.to_i) { state == "VISIBLE" ? found_element.visible?: !found_element.visible? }
end

# Check background color of element during the given time
# @param name The element's name
# @param locator_type The element's locator type
# @param locator The element's locator
# @param color The expected element's background color
# @param timeout Time out of awaiting in seconds
Then (/^"(.+)" element with (ID|CSS) "(.+)" has background color "(.+)" during (\d+)s$/) do |name, locator_type, locator, color, timeout|
  by = (locator_type == "ID") ? :id: :css;                                
  Watir::Wait.until(timeout: timeout.to_i) {
    actual_color = @browser.execute_script("return window.getComputedStyle(arguments[0], null).getPropertyValue('background-color')", @browser.element(by => locator));
    actual_color == color;
  }
end

# Check element by Applitools
# @param locator_type The element's locator type
# @param locator The element's locator
# @param win_name The name of the Applitools window in results list
Then (/^check element (ID|CSS|CLASS) "(.+)" by Applitools "(.+)"$/) do |locator_type, locator, win_name|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class;
  @eyes.check_region(by, locator)
end

# Hover on element with given location, type and name
# @param name The element's name
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
When (/^hover on "(.+)" with (ID|CSS|CLASS) "(.+)"$/) do |name, locator_type, locator|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class;
  @browser.element(by => locator).hover
end
  
# Type random user's email with given domain in a text field 
# @param domain The e-mail domain
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
# @param name The text field's name
Then (/^type random user's e-mail of domain "(.+)" in text field with (ID|CSS|CLASS) "(.+)" and name "(.+)"$/) do |domain, locator_type, locator, name|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class;
  @browser.text_field(by => locator).set(Time.now.to_i.to_s + "@" + domain)  
end

# Select options with given number in an element
# @param select_num Selection's number
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
Then (/^select option (\d+) in element with (ID|CSS|CLASS) "(.+)"$/) do |select_num, locator_type, locator|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class;
  @browser.select_list(by => locator).when_present.select_value(select_num);
end

# Select options with given text in an element 
# @param select_num Selection's number
# @param locator_type The type of the locator (ID, CSS or CLASS)
# @param locator The element's locator
Then (/^select option by text "(.+)" in element with (ID|CSS|CLASS) "(.+)"$/) do |txt, locator_type, locator|
  by = (locator_type == "ID") ? :id: (locator_type == "CSS") ? :css: :class;
  @browser.select_list(by => locator).select txt;
end