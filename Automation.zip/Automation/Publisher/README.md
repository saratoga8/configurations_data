# Publisher Automation project
Used resources:
- **Ruby**    [Documentation](https://ruby-doc.org/core-2.4.1/)
- [**Cucumber**](https://cucumber.io/)
- [**Watir**](http://www.rubydoc.info/github/watir/watir)

**IMPORTANT!**
The source code of the project should be pulled from the remote Git repository as written in the [README](http://apptfs01:8080/tfs/DefaultCollection/Webydo/_git/Automation?path=%2FREADME.md&version=GBmaster&_a=contents)

## Installation dependencies and project bulid
**Install Ruby**:
- Download and install [**Ruby**](From :http://rubyinstaller.org/downloads/)
- Set Ruby's 'bin' path folder in **Enviorment variable** (Right click on 'Computer' -> Properties -> Advanced system settings -> Environment Variables -> Path ->edit : At the end add the folder of Ruby (e.g C:\Ruby23-x64\bin))

**Install Ruby DevKit**:
- Download and extract Ruby DevKit from [**DevKit**](From : https://dl.bintray.com/oneclick/rubyinstaller/DevKit-mingw64-64-4.7.2-20130224-1432-sfx.exe) , save it in folder C:\Ruby23-x64
- Open 'Widowns PowerShell' and go to the directory of the installed Ruby DevKit and run this command to initilize the kit:
		ruby dk.rb init
- Open DevKit folder, edit the file **config.yml** add the path to the installed Ruby. (E.g. if the Ruby's path C:\Ruby23-x64, add the string '* - C:\Ruby23-x64*' to the end) 
- Return to 'PowerShell' and now install the DevKit:
		ruby dk.rb install
		
**Install Bundle**:
- Install the **Bundle** gem for building the project:
		*gem install bundle*

** Doc & Outputs folders:**		
- Create **doc** and **outputs** folders in project folder:
- Navigate to the project directory and create the directories **doc** and **outputs**

**Dependencies**:
- Build the project with all its **dependencies**:
*bundle install*

**Install ChromeDriver**:
- Download and extract [**ChromeDriver**](https://sites.google.com/a/chromium.org/chromedriver/downloads) to some directory      
- Add the path to the directory to the system variable PATH            

**Documentation Commands for first time:**     
	_yard config load_plugins true_         
	_rake yard_     
       
 ## Running the project      
For running Marketing Landing pages:    _rake cucumber[marketing]_     
For running Customer sites:             _rake cucumber[customers]_    
(Cucumber's reports with running results are in the directory **outputs**)
      
 ## Project directory structure          
	Publisher    
		|    
		+--- cucumber.yml (profiles for running cucumber)     
		|     
		+--- Gemfile (gems used by the project)          
		|        
		+--- Rakefile  (options for running project)
		|
		+--- doc (project's documentation dir)
		|
		+--- outputs (Cucumber's reports dir)    
		|    
		+--- features    
				|      
				+--- CustomerSites, MarketingLP, etc. (features)            
				|       
				+--- step_defenitions           
				|         
				+--- support      
						|          
						+--- ssl (SSL errors checking in a browser's console)      
						|       
						+--- env.rb (project's environment maintenance: e.g. initialization Applitools, 'before' and 'after' for any scenario of a feature)      
